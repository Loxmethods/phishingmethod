discord server join for more free methods: https://discord.gg/SjgQ6fNu43
